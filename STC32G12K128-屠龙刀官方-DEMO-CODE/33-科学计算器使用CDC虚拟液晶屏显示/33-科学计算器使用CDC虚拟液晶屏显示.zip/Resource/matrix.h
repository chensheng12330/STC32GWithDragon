#ifndef _MATRIX_H_
#define _MATRIX_H_

#include "middle.h"

void Ranks_Set(u8 keynum);
void Ranks_Amend(u8 keynum);
void Ranks_Caculate(u8 keynum);

void Ranks_2_4Set(u8 keynum);
void Ranks_AmendA(u8 keynum);
void Ranks_AmendB(u8 keynum);
void Ranks_Caculate2(u8 keynum);
void Ranks_Setpower(u8 keynum);    
void Ranks_Caculate3(u8 keynum) ;
void Ranks_changeCaculate(u8 keynum);

#endif

	
	
