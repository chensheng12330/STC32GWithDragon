#ifndef _SOLVE_EQUATION_H_
#define _SOLVE_EQUATION_H_

#define uchar unsigned char
#define uint unsigned int

void solve_equation();

#endif