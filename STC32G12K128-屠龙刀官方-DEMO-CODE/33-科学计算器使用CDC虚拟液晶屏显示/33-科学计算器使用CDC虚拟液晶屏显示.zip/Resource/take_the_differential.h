#ifndef _TAKE_THE_DIFFERENTIAL_H_
#define _TAKE_THE_DIFFERENTIAL_H_

#define uchar unsigned char
#define uint unsigned int

void run_the_differential();
 
#endif
