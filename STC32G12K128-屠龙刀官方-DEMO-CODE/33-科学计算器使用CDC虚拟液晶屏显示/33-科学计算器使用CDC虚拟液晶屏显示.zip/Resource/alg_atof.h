#ifndef _ALG_ATOF_H_
#define _ALG_ATOF_H_

#include "stc.h"

double
alg_atof(char *s);

#endif