#ifndef _NORMAL_COMPLEX_CACULATE_H_
#define _NORMAL_COMPLEX_CACULATE_H_

#define uchar unsigned char
#define uint unsigned int

void normal_calculate(void);

void complex_calculate(void);


#endif