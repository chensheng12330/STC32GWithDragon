#ifndef _CHANGE_UNITS_H_
#define _CHANGE_UNITS_H_

#define uchar unsigned char
#define uint unsigned int

void change_units();
 
#endif
