#ifndef _ERCHENGFA_H_
#define _ERCHENGFA_H_

#define uchar unsigned char
#define uint unsigned int



er_menu();


#endif
