#ifndef __SOLVE_H
#define __SOLVE_H

#include "middle.h"


void Solve(u8 keynum);

#endif



