#ifndef __FUNCPIC_H
#define __FUNCPIC_H

#include "middle.h"

void FuncPic_SetX0(u8 keynum);
void FuncPic_SetY0(u8 keynum);
void FuncPic_SetKX(u8 keynum);
void FuncPic_SetKY(u8 keynum);
void FuncPic_Write(u8 keynum);
void FuncPic_ShowPic(u8 keynum);

#endif


