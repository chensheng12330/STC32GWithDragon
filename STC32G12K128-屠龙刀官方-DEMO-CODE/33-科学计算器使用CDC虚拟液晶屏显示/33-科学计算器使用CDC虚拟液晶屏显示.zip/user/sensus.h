#ifndef __SENSUS_H
#define __SENSUS_H

#include "middle.h"

void Sensus_Set(u8 keynum);
void Sensus_Amend(u8 keynum);
void Sensus_Check(u8 keynum);        //���ݲ鿴
void Sensus_Check2(u8 keynum);        //���ݲ鿴

#endif 







